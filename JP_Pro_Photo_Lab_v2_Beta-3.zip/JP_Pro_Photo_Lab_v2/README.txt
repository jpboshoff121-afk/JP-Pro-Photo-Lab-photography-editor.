JP PRO PHOTO LAB — VERSION 2 BETA
==================================

WHAT THIS BUILD DOES
- Tablet-friendly photo workspace.
- Batch import of common browser-decodable images.
- Basic technical ranking using image brightness, contrast/variance and edge changes.
- Manual sliders for exposure-like brightness, contrast, highlights, shadows, warmth, saturation, sharpening and vignette.
- Conservative automatic starting corrections.
- Copy a look across a shoot.
- Before/after preview.
- Export edited copies as JPEG, PNG or WebP.
- Local browser processing; images are not uploaded by this app.
- PWA service worker for offline app-shell caching when hosted correctly.

IMPORTANT LIMITATIONS — PLEASE READ
This is a functional starter beta, NOT a complete Lightroom/Photoshop replacement.
1. A real RAW development engine is NOT included. CR2, CR3, NEF, ARW, RAF, ORF, RW2, PEF and similar files cannot be developed by this build. A DNG may work only if the browser itself can decode it.
2. The “AI Professional” mode uses local heuristic adjustments. It is not a neural AI model and does not perform face-aware retouching, generative fill, object removal, semantic subject masking, or neural denoising.
3. Photo ranking is a simple technical heuristic. It cannot reliably recognise the best expression, the key moment, blinked eyes, artistic composition or duplicate burst frames. Review before delivery.
4. Canvas exports re-encode the image and this beta does NOT preserve or guarantee EXIF/IPTC/XMP metadata in exported files. Original files are not modified; keep them as archival masters.
5. Browser memory and download restrictions may limit very large shoots. Export currently triggers separate downloads for each image.
6. Sharpening and tonal sliders are prototype-level and should be checked at 100% zoom before professional delivery.

HOW TO USE ON ANDROID
Option A — quick test:
1. Extract the ZIP using your Android file manager.
2. Open index.html in a browser. Some browsers restrict app features when opened from a local file.
3. Import JPEG/PNG/WebP and test the controls.

Option B — installable/offline PWA:
1. Upload the extracted files to a static HTTPS host such as GitHub Pages.
2. Open the HTTPS site in Chrome on Android.
3. Use Chrome menu > Add to Home screen / Install app.
4. Open once while online so the app shell is cached. Offline availability depends on browser storage policy.

NEXT ENGINEERING STEPS FOR THE REQUESTED COMPLETE APP
- Integrate and test a compiled LibRaw/WebAssembly RAW decoder/developer, with camera-specific support testing.
- Add reliable EXIF/IPTC/XMP read/write support and verify round-trip metadata.
- Add a genuine on-device AI inference pipeline for selection, denoising, subject-aware edits and portrait retouching.
- Implement safe batch export to ZIP and a non-destructive edit history.
- Add RAW previews, white balance controls, demosaic options, colour profiles and high-bit-depth TIFF output where supported.

Do not advertise RAW or AI features as complete until these engines are actually integrated and tested.
