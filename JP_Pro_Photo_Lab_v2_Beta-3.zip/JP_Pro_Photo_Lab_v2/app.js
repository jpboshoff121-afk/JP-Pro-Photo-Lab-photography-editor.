const $=id=>document.getElementById(id);
const state={photos:[],active:-1,mode:"manual",compare:false,settings:{exposure:0,contrast:0,highlights:0,shadows:0,warmth:0,saturation:0,sharpness:0,vignette:0}};
const definitions=[
 {key:"exposure",label:"Exposure",min:-100,max:100,unit:""},
 {key:"contrast",label:"Contrast",min:-60,max:60,unit:""},
 {key:"highlights",label:"Highlights",min:-60,max:60,unit:""},
 {key:"shadows",label:"Shadows",min:-60,max:60,unit:""},
 {key:"warmth",label:"White balance · warmth",min:-40,max:40,unit:""},
 {key:"saturation",label:"Saturation",min:-50,max:50,unit:""},
 {key:"sharpness",label:"Sharpening",min:0,max:100,unit:""},
 {key:"vignette",label:"Vignette",min:0,max:60,unit:""}
];
function setStatus(s){$("status").textContent=s}
function active(){return state.photos[state.active]||null}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function defaultSettings(){return {exposure:0,contrast:0,highlights:0,shadows:0,warmth:0,saturation:0,sharpness:0,vignette:0}}
function buildSliders(){
 $("sliders").innerHTML=definitions.map(d=>`<div class="field"><label for="s_${d.key}">${d.label}<output id="o_${d.key}">0</output></label><input type="range" id="s_${d.key}" min="${d.min}" max="${d.max}" value="0" step="1"></div>`).join("");
 definitions.forEach(d=>$("s_"+d.key).addEventListener("input",e=>{
   const p=active(); if(!p)return;
   p.settings[d.key]=Number(e.target.value);$("o_"+d.key).textContent=e.target.value;
   renderPreview();
 }));
}
function settingsToCSS(s){
 const bright=100+s.exposure*.42+s.shadows*.12;
 const contrast=100+s.contrast*.65;
 const sat=100+s.saturation*.75;
 const sep=Math.max(0,s.warmth)*.08;
 const hue=Math.min(0,s.warmth)*-.12;
 return `brightness(${clamp(bright,55,145)}%) contrast(${clamp(contrast,60,145)}%) saturate(${clamp(sat,50,150)}%) sepia(${clamp(sep,0,4)}%) hue-rotate(${hue}deg)`;
}
function makeProcessedCanvas(p){
 const img=p.img;if(!img)throw Error("This file could not be decoded by the browser.");
 let w=img.naturalWidth||img.width,h=img.naturalHeight||img.height;
 const max=Number($("maxSize").value)||0;
 if(max&&Math.max(w,h)>max){const scale=max/Math.max(w,h);w=Math.round(w*scale);h=Math.round(h*scale)}
 const canvas=document.createElement("canvas");canvas.width=w;canvas.height=h;
 const ctx=canvas.getContext("2d",{willReadFrequently:true});ctx.drawImage(img,0,0,w,h);
 const s=p.settings;
 let imageData=ctx.getImageData(0,0,w,h),d=imageData.data;
 const exposure=Math.pow(2,s.exposure/100);
 const contrast=1+s.contrast/100;
 const sat=1+s.saturation/100;
 const warm=s.warmth*0.45;
 for(let i=0;i<d.length;i+=4){
  let r=d[i]*exposure,g=d[i+1]*exposure,b=d[i+2]*exposure;
  const lum=.2126*r+.7152*g+.0722*b;
  const shadow=(1-lum/255)*s.shadows*.75;
  const high=(lum/255)*s.highlights*.75;
  r+=shadow-high;g+=shadow-high;b+=shadow-high;
  r=(r-128)*contrast+128+warm;b=(b-128)*contrast+128-warm;g=(g-128)*contrast+128;
  const l=.2126*r+.7152*g+.0722*b;
  r=l+(r-l)*sat;g=l+(g-l)*sat;b=l+(b-l)*sat;
  d[i]=clamp(r,0,255);d[i+1]=clamp(g,0,255);d[i+2]=clamp(b,0,255);
 }
 ctx.putImageData(imageData,0,0);
 if(s.sharpness>0){
  const src=ctx.getImageData(0,0,w,h),orig=src.data;
  const amount=s.sharpness/100*.65;
  const out=ctx.createImageData(w,h),od=out.data;
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
   const i=(y*w+x)*4;
   for(let c=0;c<3;c++){
    const blur=(orig[i-4+c]+orig[i+4+c]+orig[i-w*4+c]+orig[i+w*4+c])/4;
    od[i+c]=clamp(orig[i+c]+(orig[i+c]-blur)*amount,0,255);
   }od[i+3]=orig[i+3];
  }ctx.putImageData(out,0,0);
 }
 if(s.vignette>0){
  const grd=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.2,w/2,h/2,Math.max(w,h)*.72);
  grd.addColorStop(0,"rgba(0,0,0,0)");grd.addColorStop(1,`rgba(0,0,0,${s.vignette/100*.7})`);
  ctx.fillStyle=grd;ctx.fillRect(0,0,w,h);
 }
 return canvas;
}
function renderPreview(){
 const p=active();if(!p)return;
 const host=$("preview");host.innerHTML="";
 if(!p.img){host.innerHTML='<div class="empty"><strong>RAW file not decoded</strong><p>This beta does not include a RAW engine yet.</p></div>';return}
 const img=document.createElement("img");img.alt=p.file.name;
 if(state.compare){img.src=p.originalURL;img.style.filter="none"}else{
   // CSS preview is instant; export uses pixel processing.
   img.src=p.originalURL;img.style.filter=settingsToCSS(p.settings);
 }
 host.appendChild(img);
}
function loadSettingsToUI(s){definitions.forEach(d=>{$("s_"+d.key).value=s[d.key];$("o_"+d.key).textContent=s[d.key]})}
function updateButtons(){
 const has=state.photos.length>0, p=active();
 $("countBadge").textContent=`${state.photos.length} photo${state.photos.length===1?"":"s"}`;
 ["autoAllBtn","exportAllBtn","sortBtn","applyLookBtn","autoOneBtn","resetBtn","compareBtn","prevBtn","nextBtn"].forEach(id=>$(id).disabled=!has);
 $("prevBtn").disabled=!has||state.active<=0;$("nextBtn").disabled=!has||state.active>=state.photos.length-1;
}
function renderThumbs(){
 const host=$("thumbs");host.innerHTML="";
 if(!state.photos.length){host.innerHTML='<div class="empty">No photos imported yet.</div>';return}
 state.photos.forEach((p,i)=>{
  const el=document.createElement("div");el.className="thumb"+(i===state.active?" selected":"");
  const thumb=p.img?`<img src="${p.originalURL}" alt="">`:`<div style="aspect-ratio:4/3;display:grid;place-items:center;color:#d7ad6b">RAW</div>`;
  el.innerHTML=`${thumb}<span class="star">#${i+1} · ${p.score==null?"—":p.score}</span><div class="meta">${escapeHTML(p.file.name)}<br><span class="score">${p.score==null?"RAW / unsupported":p.scoreLabel}</span></div>`;
  el.onclick=()=>selectPhoto(i);host.appendChild(el);
 });
}
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function selectPhoto(i){state.active=i;state.compare=false;const p=active();if(p)loadSettingsToUI(p.settings);renderPreview();renderThumbs();updateButtons();$("compareBtn").textContent="Show original"}
function analyseImage(img){
 const c=document.createElement("canvas"),w=96,h=96;c.width=w;c.height=h;const x=c.getContext("2d",{willReadFrequently:true});x.drawImage(img,0,0,w,h);
 const a=x.getImageData(0,0,w,h).data;let sum=0,sum2=0,under=0,over=0,edges=0,n=0,prev=0;
 for(let y=0;y<h;y++)for(let xx=0;xx<w;xx++){
  const i=(y*w+xx)*4,l=.2126*a[i]+.7152*a[i+1]+.0722*a[i+2];sum+=l;sum2+=l*l;if(l<20)under++;if(l>240)over++;
  if(xx){edges+=Math.abs(l-prev);n++}prev=l;
 }
 const mean=sum/(w*h),variance=Math.max(0,sum2/(w*h)-mean*mean),edge=edges/Math.max(1,n);
 const exposurePenalty=Math.abs(mean-128)/128*35, clipping=(under+over)/(w*h)*80;
 const score=Math.round(clamp(50+Math.min(25,edge*.9)+Math.min(20,Math.sqrt(variance)/3)-exposurePenalty-clipping,0,100));
 return {score,mean,variance,edge,scoreLabel:score>=75?"Strong technical score":score>=55?"Review / possible keeper":"Check focus or exposure"};
}
function autoSettings(p){
 if(!p.img)return;
 // Conservative heuristic based on thumbnail luminance; this is not neural AI.
 const info=p.analysis||analyseImage(p.img);const s=defaultSettings();
 s.exposure=clamp(Math.round((118-info.mean)*.38),-30,30);
 s.contrast=clamp(Math.round((Math.sqrt(info.variance)-58)*.22),-8,12);
 s.shadows=info.mean<95?18:info.mean<115?9:0;
 s.highlights=info.mean>165?-12:0;
 s.saturation=2;
 s.sharpness=info.edge<20?12:5;
 s.warmth=0;
 p.settings=s;p.autoApplied=true;
}
async function importFiles(fileList){
 const files=Array.from(fileList);if(!files.length)return;
 setStatus("Importing photos…");$("progressBar").style.width="0%";
 let added=0;
 for(let i=0;i<files.length;i++){
  const file=files[i],ext=file.name.split(".").pop().toLowerCase();
  const raw=["dng","cr2","cr3","nef","arw","raf","orf","rw2","pef","srw"].includes(ext);
  const url=URL.createObjectURL(file);
  const p={file,originalURL:url,img:null,settings:defaultSettings(),score:null,scoreLabel:raw?"RAW engine required":"Not analysed",analysis:null,raw};
  if(!raw){
   try{const img=new Image();img.decoding="async";img.src=url;await img.decode();p.img=img;p.analysis=analyseImage(img);p.score=p.analysis.score;p.scoreLabel=p.analysis.scoreLabel}
   catch(e){p.score=null;p.scoreLabel="Unsupported image"}
  }
  state.photos.push(p);added++;
  $("progressBar").style.width=Math.round((i+1)/files.length*100)+"%";
  if(i%4===0)await new Promise(r=>setTimeout(r,0));
 }
 if(state.active<0){const first=state.photos.findIndex(p=>p.img);state.active=first>=0?first:0}
 selectPhoto(state.active);renderThumbs();updateButtons();renderAnalysis();
 const rawCount=state.photos.filter(p=>p.raw).length;
 setStatus(`Imported ${added} file(s). ${rawCount?rawCount+" RAW file(s) need a RAW engine. ":""}Originals were not changed.`);
}
function renderAnalysis(){
 const usable=state.photos.filter(p=>p.score!=null);
 if(!state.photos.length){$("analysis").textContent="Import photos to calculate basic technical scores.";return}
 if(!usable.length){$("analysis").textContent="No imported files could be decoded. RAW development is not included in this beta.";return}
 const sorted=[...usable].sort((a,b)=>b.score-a.score);
 const avg=Math.round(usable.reduce((a,p)=>a+p.score,0)/usable.length);
 $("analysis").innerHTML=`<b>${usable.length}</b> decoded photo(s) analysed.<br>Average technical score: <b>${avg}/100</b>.<br>Highest-ranked: <b>${escapeHTML(sorted[0].file.name)}</b> (${sorted[0].score}/100).<br><br>Ranking is a basic exposure/contrast/edge heuristic, not a reliable judgement of artistic quality, expressions or whether a moment is important. Review before deleting or delivering anything.`;
}
function rankPhotos(){state.photos.sort((a,b)=>(b.score??-1)-(a.score??-1));const p=active();state.active=p?state.photos.indexOf(p):0;selectPhoto(state.active);renderAnalysis();setStatus("Sorted by technical score. Check the results manually.")}
function autoAll(){let count=0;state.photos.forEach(p=>{if(p.img){autoSettings(p);count++}});if(active())loadSettingsToUI(active().settings);renderPreview();renderThumbs();setStatus(`Applied automatic starting corrections to ${count} decoded photo(s). Review each result.`)}
function exportPhoto(p,index){
 if(!p.img)throw Error(`${p.file.name}: unsupported or RAW file`);
 const canvas=makeProcessedCanvas(p),type=$("format").value,q=Number($("quality").value)/100;
 return new Promise((resolve,reject)=>canvas.toBlob(blob=>{if(!blob)return reject(Error("Export failed"));const a=document.createElement("a");const url=URL.createObjectURL(blob);a.href=url;const ext=type==="image/jpeg"?"jpg":type==="image/png"?"png":"webp";a.download=p.file.name.replace(/\.[^.]+$/,"")+"_JPPro."+ext;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);resolve()},type,q));
}
async function exportAll(){const ready=state.photos.filter(p=>p.img);if(!ready.length){setStatus("No supported decoded photos to export.");return}let done=0;for(const p of ready){try{await exportPhoto(p,done);done++;$("progressBar").style.width=Math.round(done/ready.length*100)+"%";setStatus(`Exported ${done} of ${ready.length}…`);await new Promise(r=>setTimeout(r,180))}catch(e){setStatus(e.message)}}setStatus(`Exported ${done} photo(s). Check your Downloads folder. Exported files may not retain EXIF/IPTC/XMP metadata.`)}
buildSliders();
$("importBtn").onclick=()=>$("fileInput").click();
$("fileInput").onchange=e=>importFiles(e.target.files);
$("autoAllBtn").onclick=autoAll;
$("exportAllBtn").onclick=exportAll;
$("sortBtn").onclick=rankPhotos;
$("manualMode").onclick=()=>{state.mode="manual";$("manualMode").classList.add("active");$("aiMode").classList.remove("active");setStatus("Manual Studio selected.")};
$("aiMode").onclick=()=>{state.mode="ai";$("aiMode").classList.add("active");$("manualMode").classList.remove("active");if(active())autoSettings(active());if(active())loadSettingsToUI(active().settings);renderPreview();renderThumbs();setStatus("AI Professional mode selected. Automatic corrections are heuristic, not a neural AI model.")};
$("autoOneBtn").onclick=()=>{const p=active();if(!p)return;autoSettings(p);loadSettingsToUI(p.settings);renderPreview();renderThumbs();setStatus("Automatic starting corrections applied. Review the result.")};
$("applyLookBtn").onclick=()=>{const p=active();if(!p)return;state.photos.forEach(q=>{if(q!==p)q.settings={...p.settings}});renderThumbs();setStatus("Copied current adjustments to all photos. Different lighting may require individual correction.")};
$("resetBtn").onclick=()=>{const p=active();if(!p)return;p.settings=defaultSettings();loadSettingsToUI(p.settings);renderPreview();renderThumbs();setStatus("Photo settings reset.")};
$("compareBtn").onclick=()=>{state.compare=!state.compare;renderPreview();$("compareBtn").textContent=state.compare?"Show edit":"Show original"};
$("prevBtn").onclick=()=>{if(state.active>0)selectPhoto(state.active-1)};
$("nextBtn").onclick=()=>{if(state.active<state.photos.length-1)selectPhoto(state.active+1)};
$("quality").oninput=e=>$("qualityVal").textContent=e.target.value+"%";
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
